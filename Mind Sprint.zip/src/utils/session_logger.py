from __future__ import annotations

import csv
import os
import time
from typing import Iterable, Optional


class SessionLogger:
    def __init__(self, file_path: Optional[str]) -> None:
        self._file_path = file_path
        self._csv = None
        self._file = None
        self._start_time_s = time.time()

        if self._file_path:
            os.makedirs(os.path.dirname(self._file_path) or ".", exist_ok=True)
            self._file = open(self._file_path, "w", newline="", encoding="utf-8")
            self._csv = csv.writer(self._file)
            self._csv.writerow(["ts", "event", "exercise", "rep", "status", "cues"])  # header

    def _ts(self) -> float:
        return time.time() - self._start_time_s

    def start(self, exercise: str) -> None:
        self._write("start", exercise=exercise)

    def end(self, exercise: str) -> None:
        self._write("end", exercise=exercise)

    def rep(self, exercise: str, rep_count: int, status: str = "") -> None:
        self._write("rep", exercise=exercise, rep=rep_count, status=status)

    def cues(self, exercise: str, cues: Iterable[str]) -> None:
        cues_text = "; ".join(cues)
        if cues_text:
            self._write("cues", exercise=exercise, cues=cues_text)

    def _write(self, event: str, exercise: str = "", rep: Optional[int] = None, status: str = "", cues: str = "") -> None:
        if self._csv:
            self._csv.writerow([f"{self._ts():.3f}", event, exercise, rep if rep is not None else "", status, cues])

    def close(self) -> None:
        if self._file:
            try:
                self._file.flush()
            finally:
                self._file.close()
                self._file = None
                self._csv = None


