from typing import Tuple

import numpy as np


Point = Tuple[int, int]


def _to_vec(p1: Point, p2: Point) -> np.ndarray:
    return np.array([p2[0] - p1[0], p2[1] - p1[1]], dtype=np.float32)


def calculate_angle(a: Point, b: Point, c: Point) -> float:
    """Returns the angle ABC (in degrees) with B as the vertex.

    a, b, c are points in pixel space.
    """
    v1 = _to_vec(b, a)
    v2 = _to_vec(b, c)
    denom = np.linalg.norm(v1) * np.linalg.norm(v2)
    if denom == 0:
        return 0.0
    cosang = float(np.clip(np.dot(v1, v2) / denom, -1.0, 1.0))
    ang = float(np.degrees(np.arccos(cosang)))
    return ang


def line_angle(p1: Point, p2: Point) -> float:
    """Angle between the horizontal and the line p1->p2 (degrees)."""
    v = _to_vec(p1, p2)
    return float(np.degrees(np.arctan2(v[1], v[0])))


