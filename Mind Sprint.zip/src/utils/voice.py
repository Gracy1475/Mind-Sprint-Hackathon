from __future__ import annotations

from typing import Optional


class Voice:
    def __init__(self, enabled: bool = False) -> None:
        self._enabled = enabled
        self._engine = None
        if self._enabled:
            try:
                import pyttsx3  # type: ignore
            except Exception:
                self._enabled = False
                return
            self._engine = pyttsx3.init()
            # Make speech short and quick
            try:
                rate = self._engine.getProperty("rate")
                self._engine.setProperty("rate", int(rate * 1.1))
            except Exception:
                pass

    def say(self, text: str) -> None:
        if not self._enabled or not self._engine:
            return
        try:
            self._engine.say(text)
            self._engine.iterate()
        except Exception:
            # Fallback to blocking speak to avoid EngineNotRunning errors
            try:
                self._engine.runAndWait()
            except Exception:
                pass

    def close(self) -> None:
        if self._engine:
            try:
                self._engine.stop()
            except Exception:
                pass
            self._engine = None


