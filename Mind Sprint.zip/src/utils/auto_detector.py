from __future__ import annotations

from typing import Dict, Tuple, Optional

from src.utils.geometry import calculate_angle


Landmarks = Dict[str, Tuple[int, int]]


def _angle_if(lm: Landmarks, a: str, b: str, c: str) -> float:
    return calculate_angle(lm[a], lm[b], lm[c]) if all(k in lm for k in (a, b, c)) else 0.0


class AutoDetector:
    def __init__(self) -> None:
        self._last_prediction: Optional[str] = None
        self._stable_count: int = 0

    def reset(self) -> None:
        self._last_prediction = None
        self._stable_count = 0

    def predict(self, lm: Optional[Landmarks]) -> Tuple[Optional[str], float, int]:
        if not lm:
            self.reset()
            return None, 0.0, 0

        # Basic joint angles
        knee = (
            (_angle_if(lm, "left_hip", "left_knee", "left_ankle") + _angle_if(lm, "right_hip", "right_knee", "right_ankle"))
            / 2.0
        )
        hip = (
            (_angle_if(lm, "left_shoulder", "left_hip", "left_knee") + _angle_if(lm, "right_shoulder", "right_hip", "right_knee"))
            / 2.0
        )
        elbow = (
            (_angle_if(lm, "left_shoulder", "left_elbow", "left_wrist") + _angle_if(lm, "right_shoulder", "right_elbow", "right_wrist"))
            / 2.0
        )

        # Relative wrist positions vs shoulders (y smaller means higher on image coords)
        left_wrist_high = 0
        right_wrist_high = 0
        if "left_wrist" in lm and "left_shoulder" in lm:
            left_wrist_high = 1 if lm["left_wrist"][1] < lm["left_shoulder"][1] else 0
        if "right_wrist" in lm and "right_shoulder" in lm:
            right_wrist_high = 1 if lm["right_wrist"][1] < lm["right_shoulder"][1] else 0

        # Feet spread
        feet_apart = 0
        if "left_ankle" in lm and "right_ankle" in lm:
            feet_apart = abs(lm["left_ankle"][0] - lm["right_ankle"][0])

        # Heuristic scores for a few exercises
        scores: Dict[str, float] = {
            "squat": 0.0,
            "pushup": 0.0,
            "plank": 0.0,
            "jumpingjacks": 0.0,
            "bicepcurl": 0.0,
            "shoulderpress": 0.0,
            "lunge": 0.0,
        }

        # Squat: knees flexed (<150), hips flexed, wrists not above shoulders
        scores["squat"] = max(0.0, (170 - knee)) + max(0.0, (160 - hip) * 0.5) - (left_wrist_high + right_wrist_high) * 10

        # Pushup: elbow flexion (<110) and hips extended (~180). This is rough without orientation.
        scores["pushup"] = max(0.0, (130 - elbow)) + max(0.0, (200 - abs(180 - hip))) * 0.2

        # Plank: elbow ~180, hip ~180, knees ~180
        scores["plank"] = max(0.0, 220 - abs(180 - elbow) - abs(180 - hip) - abs(180 - knee))

        # Jumping jacks: wrists above shoulders and feet far apart
        scores["jumpingjacks"] = (left_wrist_high + right_wrist_high) * 50 + feet_apart * 0.05

        # Bicep curl: elbow flexion prominent but wrists below shoulders
        scores["bicepcurl"] = max(0.0, (140 - elbow)) - (left_wrist_high + right_wrist_high) * 20

        # Shoulder press: wrists above shoulders, elbow nearer to 170-180
        scores["shoulderpress"] = (left_wrist_high + right_wrist_high) * 40 + max(0.0, 200 - abs(175 - elbow))

        # Lunge: one knee flexed and the other more extended
        left_knee = _angle_if(lm, "left_hip", "left_knee", "left_ankle")
        right_knee = _angle_if(lm, "right_hip", "right_knee", "right_ankle")
        scores["lunge"] = max(0.0, 180 - min(left_knee, right_knee)) + max(0.0, max(left_knee, right_knee) - 150)

        # Pick best
        name = max(scores, key=scores.get)
        confidence = scores[name]

        # Stability tracking
        if self._last_prediction == name:
            self._stable_count += 1
        else:
            self._last_prediction = name
            self._stable_count = 1

        return name, float(confidence), self._stable_count


