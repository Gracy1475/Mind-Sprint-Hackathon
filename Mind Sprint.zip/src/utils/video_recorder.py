from __future__ import annotations

import os
from typing import Optional, Tuple

import cv2


class VideoRecorder:
    def __init__(self, file_path: Optional[str], fps: int = 20, frame_size: Optional[Tuple[int, int]] = None) -> None:
        self._file_path = file_path
        self._fps = fps
        self._frame_size = frame_size
        self._writer = None
        if self._file_path:
            os.makedirs(os.path.dirname(self._file_path) or ".", exist_ok=True)

    def _ensure_writer(self, width: int, height: int) -> None:
        if not self._file_path:
            return
        if self._writer is not None:
            return
        frame_size = self._frame_size or (width, height)
        # FourCC for MP4 (avc1 may require codecs, use XVID/MP4V for broader compatibility)
        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        self._writer = cv2.VideoWriter(self._file_path, fourcc, self._fps, frame_size)

    def write(self, frame) -> None:
        if not self._file_path:
            return
        h, w = frame.shape[:2]
        self._ensure_writer(w, h)
        if self._writer:
            self._writer.write(frame)

    def close(self) -> None:
        if self._writer:
            self._writer.release()
            self._writer = None


