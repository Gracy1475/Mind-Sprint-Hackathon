from typing import Dict, Tuple, List, Optional
import os
import mediapipe as mp

import cv2

try:
    from mediapipe.tasks import python as mp_python
    from mediapipe.tasks.python import vision as mp_vision
except Exception as exc:  # pragma: no cover
    raise RuntimeError(
        "Failed to import mediapipe tasks. Ensure mediapipe>=0.10.x is installed."
    ) from exc

from .model_utils import ensure_model


LandmarkDict = Dict[str, Tuple[int, int]]
VisibilityDict = Dict[str, float]


class MultiPoseDetector:
    def __init__(self, num_poses: int = 3, min_pose_detection_confidence: float = 0.5):
        # Download official multi-person pose landmarker model if missing
        model_path = ensure_model(
            os.path.join("models", "pose_landmarker_full.task"),
            "https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_full/float16/1/pose_landmarker_full.task",
        )
        with open(model_path, "rb") as f:
            model_bytes = f.read()
        base_options = mp_python.BaseOptions(model_asset_buffer=model_bytes)
        options = mp_vision.PoseLandmarkerOptions(
            base_options=base_options,
            num_poses=num_poses,
            min_pose_detection_confidence=min_pose_detection_confidence,
            min_pose_presence_confidence=0.5,
            min_tracking_confidence=0.5,
            output_segmentation_masks=False,
        )
        self._landmarker = mp_vision.PoseLandmarker.create_from_options(options)
        self._image_shape = (0, 0)

        # Build mapping
        self._index_to_name = {idx: name.name.lower() for idx, name in enumerate(mp.solutions.pose.PoseLandmark)}

    def process(self, frame_bgr) -> List[Tuple[LandmarkDict, VisibilityDict]]:
        self._image_shape = frame_bgr.shape[:2]
        mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB))
        result = self._landmarker.detect(mp_image)

        persons: List[Tuple[LandmarkDict, VisibilityDict]] = []
        if not result or not result.pose_landmarks:
            return persons
        height, width = self._image_shape
        for lm_list in result.pose_landmarks:
            # lm_list is a list of normalized landmarks
            landmarks: LandmarkDict = {}
            visibility: VisibilityDict = {}
            for idx, lm in enumerate(lm_list):
                name = self._index_to_name.get(idx, str(idx))
                x_px = int(lm.x * width)
                y_px = int(lm.y * height)
                landmarks[name] = (x_px, y_px)
                visibility[name] = float(getattr(lm, "visibility", 1.0))
            persons.append((landmarks, visibility))
        return persons


