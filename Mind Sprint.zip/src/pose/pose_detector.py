from typing import Dict, Tuple, Optional

import cv2
import numpy as np

try:
    import mediapipe as mp
except Exception as exc:  # pragma: no cover
    raise RuntimeError(
        "Failed to import mediapipe. Please run 'pip install -r requirements.txt'."
    ) from exc


LandmarkDict = Dict[str, Tuple[int, int]]
VisibilityDict = Dict[str, float]


class PoseDetector:
    def __init__(self, model_complexity: int = 1, enable_segmentation: bool = False):
        self._mp_pose = mp.solutions.pose
        self._mp_drawing = mp.solutions.drawing_utils
        self._mp_styles = mp.solutions.drawing_styles
        self._pose = self._mp_pose.Pose(
            model_complexity=model_complexity,
            enable_segmentation=enable_segmentation,
            smooth_landmarks=True,
        )
        self._results = None
        self._frame_shape = (0, 0)

        # Build a mapping from index to name for convenience
        self._index_to_name = {idx: name.name.lower() for idx, name in enumerate(self._mp_pose.PoseLandmark)}

    def process(self, frame_bgr: np.ndarray) -> Tuple[Optional[LandmarkDict], Optional[VisibilityDict]]:
        self._frame_shape = frame_bgr.shape[:2]
        frame_rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        self._results = self._pose.process(frame_rgb)

        if not self._results.pose_landmarks:
            return None, None

        height, width = self._frame_shape
        landmarks: LandmarkDict = {}
        visibility: VisibilityDict = {}
        for idx, lm in enumerate(self._results.pose_landmarks.landmark):
            name = self._index_to_name.get(idx, str(idx))
            x_px = int(lm.x * width)
            y_px = int(lm.y * height)
            landmarks[name] = (x_px, y_px)
            visibility[name] = float(lm.visibility)
        return landmarks, visibility

    def draw(self, frame_bgr: np.ndarray) -> None:
        if not self._results or not self._results.pose_landmarks:
            return
        self._mp_drawing.draw_landmarks(
            frame_bgr,
            self._results.pose_landmarks,
            self._mp_pose.POSE_CONNECTIONS,
            landmark_drawing_spec=self._mp_styles.get_default_pose_landmarks_style(),
        )


