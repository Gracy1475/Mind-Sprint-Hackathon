import os
import urllib.request


def ensure_model(local_path: str, url: str) -> str:
    local_path = os.path.abspath(local_path)
    os.makedirs(os.path.dirname(local_path), exist_ok=True)
    if not os.path.exists(local_path):
        urllib.request.urlretrieve(url, local_path)
    return local_path


