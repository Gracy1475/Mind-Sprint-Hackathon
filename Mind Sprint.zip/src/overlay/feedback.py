from typing import Dict, Any, List, Optional

import cv2


class FeedbackOverlay:
    def __init__(self) -> None:
        self._font = cv2.FONT_HERSHEY_SIMPLEX

    def _draw_panel(self, frame, lines: List[str]) -> None:
        x, y = 10, 20
        for i, text in enumerate(lines):
            cv2.putText(frame, text, (x, y + i * 24), self._font, 0.7, (255, 255, 255), 2, cv2.LINE_AA)

    def draw(self, frame, feedback: Dict[str, Any]) -> None:
        lines: List[str] = []
        exercise = feedback.get("exercise", "")
        status = feedback.get("status", "")
        rep_count = feedback.get("rep_count", 0)
        score: Optional[float] = feedback.get("score")
        cues = feedback.get("cues", [])
        active_people = feedback.get("active_people")
        person_id = feedback.get("id")

        pid = f" | ID: {person_id}" if person_id is not None else ""
        header = f"Exercise: {exercise}{pid} | Reps: {rep_count}"
        if score is not None:
            header += f" | Score: {score:.0f}"
        if active_people is not None:
            header += f" | Active: {active_people}"
        lines.append(header)
        if status:
            lines.append(f"Status: {status}")
        for cue in cues[:3]:
            lines.append(f"- {cue}")

        self._draw_panel(frame, lines)

    def draw_instructions(self, frame, title: str, steps: List[str]) -> None:
        lines: List[str] = [f"Instruction: {title}"] + [f"{idx+1}. {s}" for idx, s in enumerate(steps)]
        self._draw_panel(frame, lines)


