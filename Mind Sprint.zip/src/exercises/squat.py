from typing import Dict, Tuple, Any

from src.utils.geometry import calculate_angle


class SquatAnalyzer:
    def __init__(self) -> None:
        self.state = "up"  # up -> down -> up
        self.rep_count = 0

    def _angles(self, lm: Dict[str, Tuple[int, int]]) -> Dict[str, float]:
        left_knee = calculate_angle(lm["left_hip"], lm["left_knee"], lm["left_ankle"]) if all(k in lm for k in ["left_hip", "left_knee", "left_ankle"]) else 0.0
        right_knee = calculate_angle(lm["right_hip"], lm["right_knee"], lm["right_ankle"]) if all(k in lm for k in ["right_hip", "right_knee", "right_ankle"]) else 0.0
        left_hip = calculate_angle(lm["left_shoulder"], lm["left_hip"], lm["left_knee"]) if all(k in lm for k in ["left_shoulder", "left_hip", "left_knee"]) else 0.0
        right_hip = calculate_angle(lm["right_shoulder"], lm["right_hip"], lm["right_knee"]) if all(k in lm for k in ["right_shoulder", "right_hip", "right_knee"]) else 0.0
        return {
            "knee": (left_knee + right_knee) / 2.0,
            "hip": (left_hip + right_hip) / 2.0,
        }

    def update(self, landmarks: Dict[str, Tuple[int, int]], visibility: Dict[str, float]) -> Dict[str, Any]:
        angles = self._angles(landmarks)
        knee = angles["knee"]
        hip = angles["hip"]

        cues = []
        status = self.state

        if self.state == "up" and knee < 140:
            self.state = "down"
            status = "down"
        elif self.state == "down" and knee > 165:
            self.state = "up"
            status = "up"
            self.rep_count += 1

        if knee > 170:
            cues.append("Unlock knees slightly")
        if hip < 70:
            cues.append("Keep chest up")

        return {
            "exercise": "squat",
            "rep_count": self.rep_count,
            "status": status,
            "cues": cues,
            "score": max(0, min(100, 100 - abs(90 - knee))),
        }


