from typing import Dict, Tuple, Any

from src.utils.geometry import calculate_angle


class ShoulderPressAnalyzer:
    def __init__(self) -> None:
        self.state = "down"
        self.rep_count = 0

    def _shoulder_angle(self, lm: Dict[str, Tuple[int, int]]) -> float:
        left = calculate_angle(lm["left_elbow"], lm["left_shoulder"], lm["left_hip"]) if all(k in lm for k in ["left_elbow", "left_shoulder", "left_hip"]) else 180.0
        right = calculate_angle(lm["right_elbow"], lm["right_shoulder"], lm["right_hip"]) if all(k in lm for k in ["right_elbow", "right_shoulder", "right_hip"]) else 180.0
        return (left + right) / 2.0

    def update(self, landmarks: Dict[str, Tuple[int, int]], visibility: Dict[str, float]) -> Dict[str, Any]:
        shoulder = self._shoulder_angle(landmarks)
        cues = []
        status = self.state

        if self.state == "down" and shoulder < 60:
            self.state = "up"; status = "up"
        elif self.state == "up" and shoulder > 150:
            self.state = "down"; status = "down"; self.rep_count += 1

        if shoulder > 160:
            cues.append("Avoid locking elbows overhead")

        return {
            "exercise": "shoulderpress",
            "rep_count": self.rep_count,
            "status": status,
            "cues": cues,
            "score": max(0, min(100, 100 - abs(70 - shoulder))),
        }


