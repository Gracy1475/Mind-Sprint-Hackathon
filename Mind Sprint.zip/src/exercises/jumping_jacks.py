from typing import Dict, Tuple, Any


class JumpingJacksAnalyzer:
    def __init__(self) -> None:
        self.state = "closed"  # closed -> open -> closed
        self.rep_count = 0

    def update(self, landmarks: Dict[str, Tuple[int, int]], visibility: Dict[str, float]) -> Dict[str, Any]:
        cues = []
        ls = landmarks.get("left_shoulder"); rs = landmarks.get("right_shoulder")
        lw = landmarks.get("left_wrist"); rw = landmarks.get("right_wrist")
        la = landmarks.get("left_ankle"); ra = landmarks.get("right_ankle")
        head = landmarks.get("nose")

        open_arms = False
        open_legs = False
        if lw and rw and head:
            open_arms = lw[1] < head[1] and rw[1] < head[1]
        if la and ra and ls and rs:
            shoulder_span = abs(rs[0] - ls[0]) if (ls and rs) else 0
            leg_span = abs(ra[0] - la[0])
            open_legs = leg_span > 0.8 * shoulder_span if shoulder_span else False

        if self.state == "closed" and open_arms and open_legs:
            self.state = "open"
        elif self.state == "open" and not (open_arms and open_legs):
            self.state = "closed"
            self.rep_count += 1

        if not open_arms:
            cues.append("Raise arms overhead")
        if not open_legs:
            cues.append("Step legs wider")

        return {
            "exercise": "jumpingjacks",
            "rep_count": self.rep_count,
            "status": self.state,
            "cues": cues,
            "score": None,
        }


