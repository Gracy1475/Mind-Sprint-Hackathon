from typing import Dict, Tuple, Any

from src.utils.geometry import calculate_angle


class PlankAnalyzer:
    def __init__(self) -> None:
        self.rep_count = 0

    def _angles(self, lm: Dict[str, Tuple[int, int]]) -> Dict[str, float]:
        left_hip = calculate_angle(lm["left_shoulder"], lm["left_hip"], lm["left_knee"]) if all(k in lm for k in ["left_shoulder", "left_hip", "left_knee"]) else 0.0
        right_hip = calculate_angle(lm["right_shoulder"], lm["right_hip"], lm["right_knee"]) if all(k in lm for k in ["right_shoulder", "right_hip", "right_knee"]) else 0.0
        return {
            "hip": (left_hip + right_hip) / 2.0,
        }

    def update(self, landmarks: Dict[str, Tuple[int, int]], visibility: Dict[str, float]) -> Dict[str, Any]:
        angles = self._angles(landmarks)
        hip = angles["hip"]
        cues = []

        if hip < 160:
            cues.append("Lift hips slightly")
        elif hip > 180:
            cues.append("Lower hips to align")

        score = max(0, min(100, 100 - abs(175 - hip)))

        return {
            "exercise": "plank",
            "rep_count": self.rep_count,
            "status": "hold",
            "cues": cues,
            "score": score,
        }


