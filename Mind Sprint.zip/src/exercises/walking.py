import time
from collections import deque
from typing import Dict, Tuple, Any, Deque


class WalkingAnalyzer:
    def __init__(self) -> None:
        self.rep_count = 0  # steps
        self._last_strike = None
        self._history: Deque[Tuple[float, int]] = deque(maxlen=200)
        self._left_prev_y: int | None = None
        self._right_prev_y: int | None = None
        self._left_wrist_prev_y: int | None = None
        self._right_wrist_prev_y: int | None = None

    def _foot_strike(self, lm: Dict[str, Tuple[int, int]]) -> str | None:
        left = lm.get("left_ankle")
        right = lm.get("right_ankle")
        strike = None
        if left and self._left_prev_y is not None and left[1] < self._left_prev_y - 2:
            strike = "left"
        if right and self._right_prev_y is not None and right[1] < self._right_prev_y - 2:
            if strike is None:
                strike = "right"
        self._left_prev_y = left[1] if left else self._left_prev_y
        self._right_prev_y = right[1] if right else self._right_prev_y
        return strike

    def _pace(self) -> int:
        now = time.time()
        self._history.append((now, self.rep_count))
        while self._history and now - self._history[0][0] > 15.0:
            self._history.popleft()
        if len(self._history) < 2:
            return 0
        dt = self._history[-1][0] - self._history[0][0]
        ds = self._history[-1][1] - self._history[0][1]
        if dt <= 0:
            return 0
        spm = int(ds / dt * 60.0)
        return max(0, spm)

    def update(self, landmarks: Dict[str, Tuple[int, int]], visibility: Dict[str, float]) -> Dict[str, Any]:
        strike = self._foot_strike(landmarks)

        lw = landmarks.get("left_wrist")
        rw = landmarks.get("right_wrist")
        arm_moved = False
        if lw and self._left_wrist_prev_y is not None and abs(lw[1] - self._left_wrist_prev_y) > 3:
            arm_moved = True
        if rw and self._right_wrist_prev_y is not None and abs(rw[1] - self._right_wrist_prev_y) > 3:
            arm_moved = True
        self._left_wrist_prev_y = lw[1] if lw else self._left_wrist_prev_y
        self._right_wrist_prev_y = rw[1] if rw else self._right_wrist_prev_y

        if strike and strike != self._last_strike and arm_moved:
            self.rep_count += 1
            self._last_strike = strike

        pace = self._pace()
        cues = []
        if pace < 80:
            cues.append("Pick up pace")
        elif pace > 140:
            cues.append("Slow down")

        return {
            "exercise": "walking",
            "rep_count": self.rep_count,
            "status": f"pace {pace} spm",
            "cues": cues,
            "score": None,
        }


