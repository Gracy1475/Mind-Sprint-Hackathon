from typing import Dict, Tuple, Any

from src.utils.geometry import calculate_angle


class PushupAnalyzer:
    def __init__(self) -> None:
        self.state = "up"  # up -> down -> up
        self.rep_count = 0

    def _angles(self, lm: Dict[str, Tuple[int, int]]) -> Dict[str, float]:
        left_elbow = calculate_angle(lm["left_shoulder"], lm["left_elbow"], lm["left_wrist"]) if all(k in lm for k in ["left_shoulder", "left_elbow", "left_wrist"]) else 0.0
        right_elbow = calculate_angle(lm["right_shoulder"], lm["right_elbow"], lm["right_wrist"]) if all(k in lm for k in ["right_shoulder", "right_elbow", "right_wrist"]) else 0.0
        left_shoulder = calculate_angle(lm["left_hip"], lm["left_shoulder"], lm["left_elbow"]) if all(k in lm for k in ["left_hip", "left_shoulder", "left_elbow"]) else 0.0
        right_shoulder = calculate_angle(lm["right_hip"], lm["right_shoulder"], lm["right_elbow"]) if all(k in lm for k in ["right_hip", "right_shoulder", "right_elbow"]) else 0.0
        return {
            "elbow": (left_elbow + right_elbow) / 2.0,
            "shoulder": (left_shoulder + right_shoulder) / 2.0,
        }

    def update(self, landmarks: Dict[str, Tuple[int, int]], visibility: Dict[str, float]) -> Dict[str, Any]:
        angles = self._angles(landmarks)
        elbow = angles["elbow"]
        cues = []
        status = self.state

        if self.state == "up" and elbow < 90:
            self.state = "down"
            status = "down"
        elif self.state == "down" and elbow > 165:
            self.state = "up"
            status = "up"
            self.rep_count += 1

        if elbow > 170:
            cues.append("Don’t lock elbows")

        return {
            "exercise": "pushup",
            "rep_count": self.rep_count,
            "status": status,
            "cues": cues,
            "score": max(0, min(100, 100 - abs(60 - elbow))),
        }


