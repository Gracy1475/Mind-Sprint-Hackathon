from typing import Dict, Tuple, Any

from src.utils.geometry import calculate_angle


class LungeAnalyzer:
    def __init__(self) -> None:
        self.state = "up"
        self.rep_count = 0
        self._side = "left"  # alternate when counted

    def _knee_angle(self, lm: Dict[str, Tuple[int, int]]) -> float:
        knee = f"{self._side}_knee"; hip = f"{self._side}_hip"; ankle = f"{self._side}_ankle"
        if knee in lm and hip in lm and ankle in lm:
            return calculate_angle(lm[hip], lm[knee], lm[ankle])
        return 180.0

    def update(self, landmarks: Dict[str, Tuple[int, int]], visibility: Dict[str, float]) -> Dict[str, Any]:
        knee = self._knee_angle(landmarks)
        cues = []
        status = self.state

        if self.state == "up" and knee < 110:
            self.state = "down"; status = "down"
        elif self.state == "down" and knee > 165:
            self.state = "up"; status = "up"; self.rep_count += 1
            self._side = "right" if self._side == "left" else "left"

        if knee > 170:
            cues.append("Bend front knee")

        return {
            "exercise": "lunge",
            "rep_count": self.rep_count,
            "status": f"{status}-{self._side}",
            "cues": cues,
            "score": max(0, min(100, 100 - abs(90 - knee))),
        }


