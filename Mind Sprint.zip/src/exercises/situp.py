from typing import Dict, Tuple, Any

from src.utils.geometry import calculate_angle


class SitUpAnalyzer:
    def __init__(self) -> None:
        self.state = "down"  # down -> up -> down
        self.rep_count = 0

    def _torso_angle(self, lm: Dict[str, Tuple[int, int]]) -> float:
        # hip angle approximates torso bend
        left = calculate_angle(lm["left_shoulder"], lm["left_hip"], lm["left_knee"]) if all(k in lm for k in ["left_shoulder", "left_hip", "left_knee"]) else 0.0
        right = calculate_angle(lm["right_shoulder"], lm["right_hip"], lm["right_knee"]) if all(k in lm for k in ["right_shoulder", "right_hip", "right_knee"]) else 0.0
        return (left + right) / 2.0

    def update(self, landmarks: Dict[str, Tuple[int, int]], visibility: Dict[str, float]) -> Dict[str, Any]:
        hip = self._torso_angle(landmarks)
        cues = []
        status = self.state

        if self.state == "down" and hip < 100:
            self.state = "up"
            status = "up"
        elif self.state == "up" and hip > 160:
            self.state = "down"
            status = "down"
            self.rep_count += 1

        if hip < 70:
            cues.append("Avoid curling too far")

        return {
            "exercise": "situp",
            "rep_count": self.rep_count,
            "status": status,
            "cues": cues,
            "score": max(0, min(100, 100 - abs(110 - hip))),
        }


