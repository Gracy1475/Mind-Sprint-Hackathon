from typing import Dict, Tuple, Any

from src.utils.geometry import calculate_angle


class BicepCurlAnalyzer:
    def __init__(self) -> None:
        self.state = "down"
        self.rep_count = 0
        self._side = "left"

    def _elbow_angle(self, lm: Dict[str, Tuple[int, int]]) -> float:
        elbow = f"{self._side}_elbow"; shoulder = f"{self._side}_shoulder"; wrist = f"{self._side}_wrist"
        if all(k in lm for k in [elbow, shoulder, wrist]):
            return calculate_angle(lm[shoulder], lm[elbow], lm[wrist])
        return 180.0

    def update(self, landmarks: Dict[str, Tuple[int, int]], visibility: Dict[str, float]) -> Dict[str, Any]:
        elbow = self._elbow_angle(landmarks)
        cues = []
        status = self.state

        if self.state == "down" and elbow < 70:
            self.state = "up"; status = "up"
        elif self.state == "up" and elbow > 160:
            self.state = "down"; status = "down"; self.rep_count += 1
            self._side = "right" if self._side == "left" else "left"

        if elbow > 170:
            cues.append("Keep slight elbow bend at top")

        return {
            "exercise": "bicepcurl",
            "rep_count": self.rep_count,
            "status": f"{status}-{self._side}",
            "cues": cues,
            "score": max(0, min(100, 100 - abs(60 - elbow))),
        }


