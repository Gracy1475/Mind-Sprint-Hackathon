from typing import Dict, Tuple, Any

from src.utils.geometry import line_angle


class SingleLegStandAnalyzer:
    def __init__(self) -> None:
        self.rep_count = 0
        self._held_time = 0.0
        self._last_time = None
        self._side = "left"  # alternate each hold

    def _sway_score(self, lm: Dict[str, Tuple[int, int]]) -> float:
        # Measure vertical alignment of shoulder-hip-ankle (frontal plane proxy)
        shoulder = lm.get(f"{self._side}_shoulder")
        hip = lm.get(f"{self._side}_hip")
        ankle = lm.get(f"{self._side}_ankle")
        if not (shoulder and hip and ankle):
            return 0.0
        trunk = abs(line_angle(shoulder, hip))
        leg = abs(line_angle(hip, ankle))
        deviation = (abs(trunk - 90) + abs(leg - 90)) / 2.0
        return max(0.0, 100.0 - deviation)

    def update(self, landmarks: Dict[str, Tuple[int, int]], visibility: Dict[str, float]) -> Dict[str, Any]:
        import time

        now = time.time()
        if self._last_time is None:
            self._last_time = now
        dt = now - self._last_time
        self._last_time = now

        # Heuristic: supporting leg ankle below other ankle indicates which leg is down
        la = landmarks.get("left_ankle")
        ra = landmarks.get("right_ankle")
        if la and ra:
            self._side = "left" if la[1] > ra[1] else "right"

        score = self._sway_score(landmarks)
        if score > 80:
            self._held_time += dt
        else:
            self._held_time = 0.0

        cues = []
        if score < 70:
            cues.append("Tighten core, focus on a point")

        # Count a rep every 10s stable hold
        if self._held_time >= 10.0:
            self.rep_count += 1
            self._held_time = 0.0

        return {
            "exercise": "single_leg",
            "rep_count": self.rep_count,
            "status": f"hold {self._side}",
            "cues": cues,
            "score": int(score),
        }


