from typing import Dict, Tuple, List


class CentroidTracker:
    def __init__(self, max_distance: float = 80.0, max_age: int = 15) -> None:
        self.max_distance = max_distance
        self.max_age = max_age
        self._next_id = 1
        self._objects: Dict[int, Tuple[float, float]] = {}
        self._ages: Dict[int, int] = {}

    def update(self, detections: List[Tuple[float, float]]) -> Dict[int, Tuple[float, float]]:
        # Increase age for existing
        for obj_id in list(self._ages.keys()):
            self._ages[obj_id] += 1

        assigned: Dict[int, Tuple[float, float]] = {}
        used_ids = set()
        for det in detections:
            best_id = None
            best_dist = 1e9
            for obj_id, centroid in self._objects.items():
                if obj_id in used_ids:
                    continue
                dx = centroid[0] - det[0]
                dy = centroid[1] - det[1]
                dist = (dx * dx + dy * dy) ** 0.5
                if dist < best_dist:
                    best_dist = dist
                    best_id = obj_id
            if best_id is not None and best_dist <= self.max_distance:
                assigned[best_id] = det
                used_ids.add(best_id)
                self._ages[best_id] = 0
            else:
                new_id = self._next_id
                self._next_id += 1
                assigned[new_id] = det
                used_ids.add(new_id)
                self._ages[new_id] = 0

        # Remove aged out
        for obj_id in list(self._objects.keys()):
            if obj_id not in assigned and self._ages.get(obj_id, 0) > self.max_age:
                self._objects.pop(obj_id, None)
                self._ages.pop(obj_id, None)

        # Commit
        self._objects.update(assigned)
        return dict(self._objects)


