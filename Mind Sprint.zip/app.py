import argparse
import time
from typing import Dict, Any

import cv2

from src.pose.pose_detector import PoseDetector
from src.pose.multi_pose_detector import MultiPoseDetector
from src.tracking.centroid_tracker import CentroidTracker
from src.overlay.feedback import FeedbackOverlay
from src.utils.session_logger import SessionLogger
from src.utils.video_recorder import VideoRecorder
from src.utils.voice import Voice
from src.utils.auto_detector import AutoDetector
from src.exercises.squat import SquatAnalyzer
from src.exercises.pushup import PushupAnalyzer
from src.exercises.plank import PlankAnalyzer
from src.exercises.jogging import JoggingAnalyzer
from src.exercises.walking import WalkingAnalyzer
from src.exercises.situp import SitUpAnalyzer
from src.exercises.single_leg import SingleLegStandAnalyzer
from src.exercises.jumping_jacks import JumpingJacksAnalyzer
from src.exercises.lunge import LungeAnalyzer
from src.exercises.bicep_curl import BicepCurlAnalyzer
from src.exercises.shoulder_press import ShoulderPressAnalyzer


EXERCISE_MAP = {
    "squat": SquatAnalyzer,
    "pushup": PushupAnalyzer,
    "plank": PlankAnalyzer,
    "jogging": JoggingAnalyzer,
    "walking": WalkingAnalyzer,
    "situp": SitUpAnalyzer,
    "singleleg": SingleLegStandAnalyzer,
    "jumpingjacks": JumpingJacksAnalyzer,
    "lunge": LungeAnalyzer,
    "bicepcurl": BicepCurlAnalyzer,
    "shoulderpress": ShoulderPressAnalyzer,
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Real-time exercise form coach")
    parser.add_argument(
        "--exercise",
        type=str,
        default="squat",
        choices=list(EXERCISE_MAP.keys()),
        help="Exercise to analyze",
    )
    parser.add_argument("--camera", type=int, default=0, help="Camera index")
    parser.add_argument("--width", type=int, default=1280, help="Capture width")
    parser.add_argument("--height", type=int, default=720, help="Capture height")
    parser.add_argument("--mirror", action="store_true", help="Mirror the preview")
    parser.add_argument("--multi", action="store_true", help="Enable multi-person tracking")
    parser.add_argument("--idle", action="store_true", help= "Enable idle detection and instruction overlay")
    parser.add_argument("--log", type=str, default=None, help="Path to CSV log file (e.g. runs/session.csv)")
    parser.add_argument("--save-video", type=str, default=None, help="Path to save annotated video (e.g. runs/session.mp4)")
    parser.add_argument("--voice", action="store_true", help="Enable voice cues for reps and key feedback")
    parser.add_argument("--save-summary", type=str, default=None, help="Path to save session summary JSON (e.g. runs/summary.json)")
    parser.add_argument("--auto", action="store_true", help="Auto-detect exercise and switch analyzer when stable")
    return parser.parse_args()


def build_analyzer(name: str):
    analyzer_cls = EXERCISE_MAP[name]
    return analyzer_cls()


def main() -> None:
    args = parse_args()

    cap = cv2.VideoCapture(args.camera)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, args.width)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, args.height)

    if not cap.isOpened():
        raise RuntimeError("Could not open camera. Try a different index with --camera.")

    single_pose = PoseDetector()
    multi_pose = MultiPoseDetector() if args.multi else None
    tracker = CentroidTracker() if args.multi else None
    overlay = FeedbackOverlay()
    logger = SessionLogger(args.log)
    recorder = VideoRecorder(args.save_video)
    voice = Voice(enabled=args.voice)
    analyzer_name = args.exercise
    analyzer = build_analyzer(analyzer_name)
    auto = AutoDetector() if args.auto else None

    last_switch_time = 0.0
    idle_last_movement_time = time.time()
    instruction_index = 0

    # Summary stats per exercise
    summary_stats: Dict[str, Dict[str, Any]] = {name: {"reps": 0, "best_score": None, "time_s": 0.0} for name in EXERCISE_MAP.keys()}
    current_ex_start = time.time()

    INSTRUCTION_STEPS: Dict[str, Any] = {
        "squat": ["Feet shoulder-width apart", "Chest up, back neutral", "Sit back to 90° knees", "Drive through heels to stand"],
        "pushup": ["Hands under shoulders", "Body straight, core tight", "Lower chest to elbow 90°", "Press up without flaring"],
        "plank": ["Elbows under shoulders", "Body in straight line", "Squeeze glutes and core", "Breathe and hold"],
        "jogging": ["Light lean forward", "Short quick steps", "Arms swing comfortably", "Relax shoulders"],
        "walking": ["Stand tall", "Natural arm swing", "Midfoot strike", "Comfortable pace"],
        "situp": ["Knees bent, feet anchored", "Engage core", "Curl up smoothly", "Lower with control"],
        "singleleg": ["Stand tall on one leg", "Fix gaze on point", "Engage core", "Switch legs"],
        "jumpingjacks": ["Start feet together, arms down", "Jump legs wide, arms overhead", "Return to start", "Find steady rhythm"],
        "lunge": ["Step forward", "Drop back knee toward floor", "Front knee ~90°", "Push back to start"],
        "bicepcurl": ["Elbows by sides", "Curl to shoulder", "Squeeze biceps", "Lower slowly"],
        "shoulderpress": ["Elbows under wrists", "Press overhead", "Avoid arching back", "Lower to ears"],
    }

    def detect_movement(landmarks_prev, landmarks_curr) -> bool:
        if not landmarks_prev or not landmarks_curr:
            return True
        keys = ["left_wrist", "right_wrist", "left_ankle", "right_ankle", "nose"]
        diffs = []
        for k in keys:
            p = landmarks_prev.get(k)
            c = landmarks_curr.get(k)
            if p and c:
                diffs.append(abs(c[0]-p[0]) + abs(c[1]-p[1]))
        if not diffs:
            return True
        avg = sum(diffs) / len(diffs)
        return avg > 6.0

    def detect_gesture_select(lm) -> str | None:
        ls = lm.get("left_shoulder"); rs = lm.get("right_shoulder")
        lw = lm.get("left_wrist"); rw = lm.get("right_wrist")
        if ls and lw and lw[1] < ls[1]:
            return "prev"
        if rs and rw and rw[1] < rs[1]:
            return "next"
        return None

    try:
        logger.start(analyzer_name)
        prev_landmarks_single = None
        last_rep_count = 0
        while True:
            ok, frame = cap.read()
            if not ok:
                break

            if args.mirror:
                frame = cv2.flip(frame, 1)

            if args.multi and multi_pose:
                persons = multi_pose.process(frame)
                centers = []
                for (lm, _vis) in persons:
                    # use hip midpoint as centroid
                    lh = lm.get("left_hip")
                    rh = lm.get("right_hip")
                    if lh and rh:
                        centers.append(((lh[0] + rh[0]) / 2.0, (lh[1] + rh[1]) / 2.0))
                id_to_center = tracker.update(centers) if tracker else {}

                # map centers back to (lm, vis) by nearest
                outputs: Dict[int, Dict[str, Any]] = {}
                for pid, center in id_to_center.items():
                    best = None
                    best_d = 1e9
                    for (lm, vis) in persons:
                        lh = lm.get("left_hip"); rh = lm.get("right_hip")
                        if not (lh and rh):
                            continue
                        cx = (lh[0] + rh[0]) / 2.0
                        cy = (lh[1] + rh[1]) / 2.0
                        d = (cx - center[0]) ** 2 + (cy - center[1]) ** 2
                        if d < best_d:
                            best_d = d
                            best = (lm, vis)
                    if best:
                        lm, vis = best
                        fb = analyzer.update(lm, vis)
                        fb["id"] = pid
                        fb["active_people"] = len(id_to_center)
                        overlay.draw(frame, fb)
            else:
                landmarks, visibility = single_pose.process(frame)
                feedback: Dict[str, Any] = {
                    "exercise": analyzer_name,
                    "rep_count": 0,
                    "status": "",
                    "cues": [],
                    "score": None,
                }
                if landmarks:
                    # Auto-detect exercise if enabled
                    if auto:
                        pred_name, conf, stable = auto.predict(landmarks)
                        if pred_name and pred_name in EXERCISE_MAP and stable >= 12 and pred_name != analyzer_name:
                            # Update time for current exercise
                            summary_stats[analyzer_name]["time_s"] += time.time() - current_ex_start
                            prev = analyzer_name
                            analyzer_name = pred_name
                            analyzer = build_analyzer(analyzer_name)
                            logger.end(prev)
                            logger.start(analyzer_name)
                            current_ex_start = time.time()
                            if args.voice:
                                voice.say(analyzer_name)
                    # Idle detection and instruction overlay
                    if args.idle:
                        if detect_movement(prev_landmarks_single, landmarks):
                            idle_last_movement_time = time.time()
                        idle_duration = time.time() - idle_last_movement_time
                        gesture = detect_gesture_select(landmarks)
                        if idle_duration > 5.0 and analyzer_name in INSTRUCTION_STEPS:
                            steps = INSTRUCTION_STEPS[analyzer_name]
                            overlay.draw_instructions(frame, analyzer_name, steps)
                            if gesture == "next":
                                keys = list(EXERCISE_MAP.keys())
                                idx = keys.index(analyzer_name)
                                analyzer_name = keys[(idx + 1) % len(keys)]
                                analyzer = build_analyzer(analyzer_name)
                                idle_last_movement_time = time.time()
                            elif gesture == "prev":
                                keys = list(EXERCISE_MAP.keys())
                                idx = keys.index(analyzer_name)
                                analyzer_name = keys[(idx - 1) % len(keys)]
                                analyzer = build_analyzer(analyzer_name)
                                idle_last_movement_time = time.time()
                        else:
                            feedback = analyzer.update(landmarks, visibility)
                            single_pose.draw(frame)
                            overlay.draw(frame, feedback)
                    else:
                        feedback = analyzer.update(landmarks, visibility)
                        single_pose.draw(frame)
                        overlay.draw(frame, feedback)

                    # Logging, voice, video after feedback produced
                    if landmarks and feedback:
                        rep_count = int(feedback.get("rep_count", 0))
                        status = str(feedback.get("status", ""))
                        cues = feedback.get("cues", []) or []
                        score = feedback.get("score")
                        if rep_count > last_rep_count:
                            logger.rep(analyzer_name, rep_count, status)
                            if args.voice:
                                voice.say(str(rep_count))
                            last_rep_count = rep_count
                            summary_stats[analyzer_name]["reps"] = rep_count
                        # Track best score
                        if isinstance(score, (int, float)):
                            best = summary_stats[analyzer_name]["best_score"]
                            summary_stats[analyzer_name]["best_score"] = score if best is None else max(best, score)
                        if cues:
                            logger.cues(analyzer_name, cues)
                prev_landmarks_single = landmarks

            cv2.imshow("Exercise Coach", frame)
            recorder.write(frame)
            key = cv2.waitKey(1) & 0xFF
            if key == ord("q"):
                break
            if key == ord("e"):
                # Debounce exercise switching
                now = time.time()
                if now - last_switch_time > 0.5:
                    keys = list(EXERCISE_MAP.keys())
                    idx = keys.index(analyzer_name)
                    # Update time for current exercise
                    summary_stats[analyzer_name]["time_s"] += time.time() - current_ex_start
                    analyzer_name = keys[(idx + 1) % len(keys)]
                    analyzer = build_analyzer(analyzer_name)
                    logger.end(keys[idx])
                    logger.start(analyzer_name)
                    current_ex_start = time.time()
                    last_switch_time = now

            # Direct selection hotkeys 1-9,0 for first 10 exercises
            if ord('1') <= key <= ord('9') or key == ord('0'):
                keys = list(EXERCISE_MAP.keys())
                sel = (key - ord('1')) if key != ord('0') else 9
                if 0 <= sel < len(keys):
                    summary_stats[analyzer_name]["time_s"] += time.time() - current_ex_start
                    prev = analyzer_name
                    analyzer_name = keys[sel]
                    analyzer = build_analyzer(analyzer_name)
                    logger.end(prev)
                    logger.start(analyzer_name)
                    current_ex_start = time.time()

    finally:
        logger.end(analyzer_name)
        # finalize time for last exercise
        summary_stats[analyzer_name]["time_s"] += time.time() - current_ex_start
        cap.release()
        cv2.destroyAllWindows()
        recorder.close()
        voice.close()
        # Print and optionally save summary
        try:
            import json
            total_reps = sum(v["reps"] for v in summary_stats.values())
            total_time = sum(v["time_s"] for v in summary_stats.values())
            best_by_ex = {k: v["best_score"] for k, v in summary_stats.items()}
            summary = {
                "total_reps": total_reps,
                "total_time_s": round(total_time, 1),
                "per_exercise": summary_stats,
                "best_scores": best_by_ex,
            }
            print("Session Summary:")
            print(json.dumps(summary, indent=2))
            if args.save_summary:
                import os
                os.makedirs(os.path.dirname(args.save_summary) or ".", exist_ok=True)
                with open(args.save_summary, "w", encoding="utf-8") as f:
                    json.dump(summary, f, indent=2)
        except Exception:
            pass


if __name__ == "__main__":
    main()


